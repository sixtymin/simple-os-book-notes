安装步骤：
1、git clone git@github.com:iamazhi/vimdoc-chinese.git
2、cd vimdoc-chinese 
3、./vimcdoc.sh -i
4、现在启动 vim/gvim, 键入 :help 看看吧！

说明：本项目拷贝[http://vimcdoc.sourceforge.net](http://vimcdoc.sourceforge.net)，版本为1.9.0，更新到Vim 7.4

