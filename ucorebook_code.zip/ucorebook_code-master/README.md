一步一步构建ucore OS(配套代码)
======================
"操作系统简单实现与基本原理 — 基于ucore" (持续更新) http://chyyuu.gitbooks.io/ucorebook/

介绍
======================
ucore OS是用于清华大学计算机系本科操作系统课程的OS教学试验内容。
ucore OS起源于MIT CSAIL PDOS课题组开发的xv6&jos、哈佛大学开发的
OS161教学操作系统、以及Linux-2.4内核。

ucore OS中包含的xv6&jos代码版权属于Frans Kaashoek, Robert Morris,
and Russ Cox，使用MIT License。ucore OS中包含的OS/161代码版权属于
David A. Holland。其他代码版权属于陈渝、王乃铮、向勇，并采用GPL License.
ucore OS相关的文档版权属于陈渝、向勇，并采用 Creative Commons 
Attribution/Share-Alike (CC-BY-SA) License. 

开发维护人员 
======================
 * 陈渝 http://soft.cs.tsinghua.edu.cn/~chen
 * 茅俊杰 eternal.n08 AT gmail.com

相关资料
======================
 * https://github.com/chyyuu/mooc_os
