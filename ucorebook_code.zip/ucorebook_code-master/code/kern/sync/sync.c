#include <sync.h>
#include <mbox.h>

void
sync_init(void) {
    mbox_init();
}

