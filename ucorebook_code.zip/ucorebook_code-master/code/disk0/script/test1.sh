ls
cd test
pwd
ls /testman > xx
cat xx
unlink xx
echo test1.sh end.

